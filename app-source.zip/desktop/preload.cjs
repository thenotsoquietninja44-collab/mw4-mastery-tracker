const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desktopApp', {
  getVersion: () => ipcRenderer.invoke('app:version'),
  onUpdateStatus: (callback) => {
    const listener = (_event, status) => callback({ message: String(status.message), state: String(status.state) });
    ipcRenderer.on('update:status', listener);
    return () => ipcRenderer.removeListener('update:status', listener);
  }
});
