const { app, BrowserWindow, Menu, protocol, net, session, shell, dialog, ipcMain } = require('electron');
const { pathToFileURL } = require('node:url');
const path = require('node:path');
const fs = require('node:fs/promises');
const { autoUpdater } = require('electron-updater');
const { writeBackup, readBackup } = require('./backups.cjs');
const { resolveAsset, isLocalPage, isExternalLink } = require('./security.cjs');
app.setName('MW4 Mastery Tracker');
protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }]);
const smokeTest = app.commandLine.hasSwitch('smoke-test');
// Startup tests must never open the user's live progress database.
if (smokeTest) app.setPath('userData', require('node:fs').mkdtempSync(path.join(require('node:os').tmpdir(), 'mw4-startup-test-')));
let mainWindow, checking = false, downloaded = false, installing = false, restoring = false;
const backupDirectory = () => path.join(app.getPath('userData'), 'progress-backups');
async function captureBackup(reason, targetVersion) {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.webContents.isLoading() || !isLocalPage(mainWindow.webContents.getURL())) throw new Error('Wait for the tracker to finish loading, then try again.');
  const data = await mainWindow.webContents.executeJavaScript("JSON.parse(JSON.stringify({format:'mw4-mastery-v1',...state}))");
  return writeBackup(backupDirectory(), data, { reason, appVersion: app.getVersion(), ...(targetVersion ? { targetVersion } : {}) });
}
async function installDownloadedUpdate() {
  if (installing || restoring) return;
  if (!downloaded) return checkUpdates(true);
  installing = true;
  try { await captureBackup('before-update-install', downloaded); autoUpdater.quitAndInstall(false, true); }
  catch (error) { installing = false; await dialog.showMessageBox(mainWindow, { type: 'error', message: 'Update paused: progress backup failed.', detail: error.message + ' Your current app has not been replaced.' }); }
}
async function restoreSavedBackup() {
  if (restoring || installing) return;
  restoring = true;
  try {
    await fs.mkdir(backupDirectory(), { recursive: true });
    const picked = await dialog.showOpenDialog(mainWindow, { title: 'Restore progress from backup', defaultPath: backupDirectory(), properties: ['openFile'], filters: [{ name: 'MW4 progress backup', extensions: ['json'] }] });
    if (picked.canceled || !picked.filePaths[0]) return;
    const data = await readBackup(picked.filePaths[0]);
    await mainWindow.webContents.executeJavaScript(`validateProgressBackup(${JSON.stringify(data)}); true`);
    const choice = await dialog.showMessageBox(mainWindow, { type: 'question', buttons: ['Restore backup', 'Cancel'], defaultId: 1, cancelId: 1, message: 'Restore this progress backup?', detail: path.basename(picked.filePaths[0]) + '\nYour current progress will be backed up before it is replaced.' });
    if (choice.response !== 0) return;
    await captureBackup('before-restore');
    await mainWindow.webContents.executeJavaScript(`restoreProgressBackup(${JSON.stringify(data)})`);
    await dialog.showMessageBox(mainWindow, { message: 'Progress restored.', detail: 'Your previous progress is also saved in the backups folder.' });
  } catch (error) { await dialog.showMessageBox(mainWindow, { type: 'error', message: 'Unable to restore backup.', detail: error.message }); }
  finally { restoring = false; }
}
async function createManualBackup() {
  try { const file = await captureBackup('manual'); await dialog.showMessageBox(mainWindow, { message: 'Progress backup saved.', detail: file }); }
  catch (error) { await dialog.showMessageBox(mainWindow, { type: 'error', message: 'Unable to save backup.', detail: error.message }); }
}
function status(state, message) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('update:status', { state, message });
}
async function checkUpdates(manual = false) {
  if (checking) return;
  if (!app.isPackaged) { status('development', 'Development build · automatic updates disabled'); return; }
  checking = true;
  try { await autoUpdater.checkForUpdates(); }
  catch { status('offline', 'Update check unavailable · app works offline'); if (manual) await dialog.showMessageBox(mainWindow, { type: 'info', message: 'Unable to check for updates. You can keep using the app offline.' }); }
  finally { checking = false; }
}
function configureUpdater() {
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = false;
  autoUpdater.allowPrerelease = false;
  autoUpdater.on('checking-for-update', () => status('checking', 'Checking for updates…'));
  autoUpdater.on('update-available', info => status('available', 'Downloading version ' + info.version + '…'));
  autoUpdater.on('update-not-available', () => status('current', 'Version ' + app.getVersion() + ' · Up to date'));
  autoUpdater.on('download-progress', progress => status('downloading', 'Downloading update · ' + Math.floor(progress.percent) + '%'));
  autoUpdater.on('error', () => status('offline', 'Update check unavailable · app works offline'));
  autoUpdater.on('update-downloaded', async info => {
    downloaded = info.version;
    try { await captureBackup('update-downloaded', info.version); } catch (error) { status('ready', 'Update ready � backup required before install'); }
    status('ready', 'Version ' + info.version + ' ready · restart to update');
    const result = await dialog.showMessageBox(mainWindow, { type: 'info', buttons: ['Restart and update', 'Later'], defaultId: 1, cancelId: 1, title: 'Update ready', message: 'Version ' + info.version + ' is ready.', detail: 'Your progress stays on this PC. Restart now to install the update.' });
    if (result.response === 0) await installDownloadedUpdate();
  });
}
function installMenu() {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'File', submenu: [{ label: 'Open progress folder', click: () => shell.openPath(app.getPath('userData')) }, { type: 'separator' }, { role: 'quit' }] },
    { label: 'View', submenu: [{ role: 'reload' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'togglefullscreen' }] },
    { label: 'Help', submenu: [{ label: 'Check for updates', click: () => checkUpdates(true) }, { label: 'Install downloaded update', click: installDownloadedUpdate }, { type: 'separator' }, { label: 'Create progress backup', click: createManualBackup }, { label: 'Restore from backup', click: restoreSavedBackup }, { label: 'Open backups folder', click: async () => { await fs.mkdir(backupDirectory(), { recursive: true }); shell.openPath(backupDirectory()); } }, { type: 'separator' }, { label: 'About', click: () => dialog.showMessageBox(mainWindow, { message: 'MW4 Mastery Tracker', detail: 'Version ' + app.getVersion() + '\nProgress saves on this PC. Use Export and Import inside the tracker to back up or transfer progress.' }) }] }
  ]));
}
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); } });
  app.whenReady().then(async () => {
    if(smokeTest)setTimeout(()=>app.exit(6),15000).unref();
    const uiRoot = path.join(app.getAppPath(), 'ui');
    const rendererSession = session.fromPartition('persist:tracker');
    rendererSession.protocol.handle('app', async request => {
      const file = resolveAsset(uiRoot, request.url);
      if (!file) return new Response('Not found', { status: 404 });
      try { await fs.access(file); return await net.fetch(pathToFileURL(file).toString()); }
      catch { return new Response('Not found', { status: 404 }); }
    });
    rendererSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
    rendererSession.setPermissionCheckHandler(() => false);
    // All renderer resources are local. Only the main-process updater can use the network.
    rendererSession.webRequest.onBeforeRequest((details, callback) => callback({ cancel: !/^(app:|data:|blob:)/.test(details.url) }));
    mainWindow = new BrowserWindow({ width: 1440, height: 940, minWidth: 900, minHeight: 600, backgroundColor: '#0c1110', title: 'MW4 Mastery Tracker', show: false, webPreferences: { partition: 'persist:tracker', preload: path.join(__dirname, 'preload.cjs'), nodeIntegration: false, contextIsolation: true, sandbox: true, webSecurity: true, spellcheck: false } });
    mainWindow.webContents.setWindowOpenHandler(({ url }) => { if (isExternalLink(url)) shell.openExternal(url); return { action: 'deny' }; });
    mainWindow.webContents.on('will-navigate', (event, url) => { if (!isLocalPage(url)) { event.preventDefault(); if (isExternalLink(url)) shell.openExternal(url); } });
    ipcMain.handle('app:version', event => { if (!isLocalPage(event.senderFrame.url)) throw new Error('Invalid sender'); return app.getVersion(); });
    mainWindow.once('ready-to-show', () => { if (!smokeTest) mainWindow.show(); });
    if(smokeTest){mainWindow.webContents.on('preload-error',()=>app.exit(2));mainWindow.webContents.on('render-process-gone',()=>app.exit(3));mainWindow.webContents.on('did-fail-load',()=>app.exit(4));mainWindow.webContents.on('console-message',(_event,details)=>{if(details.level==='error')app.exit(5)});}
    mainWindow.webContents.once('did-finish-load', () => { if (smokeTest) { setTimeout(() => app.exit(0), 2500); } else if (app.isPackaged) checkUpdates(); });
    configureUpdater(); installMenu();
    await mainWindow.loadURL('app://tracker/index.html');
  }).catch(error => { if(smokeTest){console.error(error);app.exit(1);return;} dialog.showErrorBox('Unable to start MW4 Mastery Tracker', String(error.message)); app.quit(); });
}
app.on('window-all-closed', () => app.quit());
