const path = require('node:path');
function resolveAsset(root, requestUrl) {
  const url = new URL(requestUrl);
  if (url.protocol !== 'app:' || url.hostname !== 'tracker') return null;
  let decoded;
  try { decoded = decodeURIComponent(url.pathname); } catch { return null; }
  if (decoded.includes('\\') || decoded.includes('\0')) return null;
  const relative = decoded === '/' ? 'index.html' : decoded.slice(1);
  const target = path.resolve(root, relative);
  const difference = path.relative(root, target);
  if (difference.startsWith('..') || path.isAbsolute(difference)) return null;
  return target;
}
function isLocalPage(url) {
  try { const u = new URL(url); return u.protocol === 'app:' && u.hostname === 'tracker'; } catch { return false; }
}
function isExternalLink(url) {
  try { return new URL(url).protocol === 'https:'; } catch { return false; }
}
module.exports = { resolveAsset, isLocalPage, isExternalLink };
