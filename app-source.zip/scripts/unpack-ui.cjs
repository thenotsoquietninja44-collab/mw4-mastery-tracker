const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),manifest=JSON.parse(fs.readFileSync(path.join(root,'ui-assets.json'),'utf8'));
const archive=Buffer.concat(manifest.parts.map(name=>{if(!/^ui-assets\.part\d{3}$/.test(name))throw Error('Invalid archive part');return fs.readFileSync(path.join(root,name))}));
if(crypto.createHash('sha256').update(archive).digest('hex')!==manifest.sha256)throw Error('UI archive checksum mismatch');
fs.mkdirSync(path.join(root,'.build'),{recursive:true});fs.writeFileSync(path.join(root,'.build','ui.zip'),archive);console.log('UI archive verified; expand .build/ui.zip in the project folder.');
const updateManifest=path.join(root,'ui-update-parts.json');
if(fs.existsSync(updateManifest)){
 const update=JSON.parse(fs.readFileSync(updateManifest,'utf8'));
 const bytes=Buffer.concat(update.parts.map(name=>{if(!/^ui-update\.part\d{3}$/.test(name))throw Error('Invalid update archive part');return fs.readFileSync(path.join(root,name))}));
 if(crypto.createHash('sha256').update(bytes).digest('hex')!==update.sha256)throw Error('Update archive checksum mismatch');
 fs.writeFileSync(path.join(root,'ui-update.zip'),bytes);console.log('Updated offline UI archive verified and assembled.');
}
const layoutManifest=path.join(root,'ui-layout-parts.json');
if(fs.existsSync(layoutManifest)){
 const layout=JSON.parse(fs.readFileSync(layoutManifest,'utf8'));
 const bytes=Buffer.concat(layout.parts.map(name=>{if(!/^ui-layout\.part\d{3}$/.test(name))throw Error('Invalid layout archive part');return fs.readFileSync(path.join(root,name))}));
 if(crypto.createHash('sha256').update(bytes).digest('hex')!==layout.sha256)throw Error('Guide/layout archive checksum mismatch');
 fs.writeFileSync(path.join(root,'ui-layout.zip'),bytes);console.log('Visual guides and latest UI verified and assembled.');
}

const latestManifest=path.join(root,'ui-latest-parts.json');
if(fs.existsSync(latestManifest)){
 const latest=JSON.parse(fs.readFileSync(latestManifest,'utf8'));
 const bytes=Buffer.concat(latest.parts.map(name=>{if(!/^ui-latest\.part\d{3}$/.test(name))throw Error('Invalid latest archive part');return fs.readFileSync(path.join(root,name))}));
 if(crypto.createHash('sha256').update(bytes).digest('hex')!==latest.sha256)throw Error('Latest archive checksum mismatch');
 fs.writeFileSync(path.join(root,'ui-latest.zip'),bytes);console.log('Latest camo artwork and challenge UI verified and assembled.');
}
