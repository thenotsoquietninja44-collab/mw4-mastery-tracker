const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),manifest=JSON.parse(fs.readFileSync(path.join(root,'ui-assets.json'),'utf8'));
const archive=Buffer.concat(manifest.parts.map(name=>{if(!/^ui-assets\.part\d{3}$/.test(name))throw Error('Invalid archive part');return fs.readFileSync(path.join(root,name))}));
if(crypto.createHash('sha256').update(archive).digest('hex')!==manifest.sha256)throw Error('UI archive checksum mismatch');
fs.mkdirSync(path.join(root,'.build'),{recursive:true});fs.writeFileSync(path.join(root,'.build','ui.zip'),archive);console.log('UI archive verified; expand .build/ui.zip in the project folder.');
