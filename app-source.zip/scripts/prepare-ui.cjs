const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),src=path.resolve(root,'../sites/mastery/dist'),out=path.join(root,'ui');
fs.mkdirSync(out,{recursive:true});
for(const name of fs.readdirSync(src))if(/\.(js|html|css)$/.test(name))fs.copyFileSync(path.join(src,name),path.join(out,name));
fs.mkdirSync(path.join(out,'assets'),{recursive:true});
for(const entry of fs.readdirSync(path.join(src,'assets'),{withFileTypes:true})){
 if(entry.isDirectory()&&!['central-icons','tac-icons','item-sheets','u4gm','reticles','calling-cards'].includes(entry.name))continue;
 fs.cpSync(path.join(src,'assets',entry.name),path.join(out,'assets',entry.name),{recursive:true});
}
let data=fs.readFileSync(path.join(out,'data.js'),'utf8').replace(/^\uFEFF/,'');const parsed=JSON.parse(data.slice(data.indexOf('=')+1).trim().replace(/;$/,''));
for(const key of Object.keys(parsed.initial))parsed.initial[key]=false;
fs.writeFileSync(path.join(out,'data.js'),'const DATA='+JSON.stringify(parsed)+';\n');
let html=fs.readFileSync(path.join(out,'index.html'),'utf8');html=html.replace('</body>','<script src="desktop-status.js"></script></body>');
html=html.replace('Progress starts from your workbook and saves automatically in this browser.','Progress saves automatically on this PC.');
fs.writeFileSync(path.join(out,'index.html'),html);
fs.writeFileSync(path.join(out,'desktop-status.js'),`if(window.desktopApp){const s=document.createElement('p');s.className='desktop-update-status';s.setAttribute('role','status');document.querySelector('.side-bottom').appendChild(s);window.desktopApp.onUpdateStatus(x=>{s.textContent=x.message});window.desktopApp.getVersion().then(v=>{s.textContent='Version '+v+' · Offline ready'});}`);
console.log('Desktop UI prepared with blank progress and local assets.');
