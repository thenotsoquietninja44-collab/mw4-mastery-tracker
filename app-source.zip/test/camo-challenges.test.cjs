const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
test('all 462 weapon camo challenges match the verified catalog and keep stable progress IDs',()=>{
 const data=JSON.parse(fs.readFileSync(path.join(root,'ui/data.js'),'utf8').split('=').slice(1).join('=').trim().replace(/;$/,''));
 const expected=require('./fixtures/camo-challenges-20261103.json');assert.equal(expected.length,462);
 for(const row of expected){const w=data.weapons.find(x=>x.name===row.weapon),c=w.camos.find(x=>x.id===row.id);assert.ok(c);assert.equal(c.mp,row.mp);assert.equal(c.dmz,row.dmz);assert.ok(Object.hasOwn(data.initial,c.id));assert.ok(fs.existsSync(path.join(root,'ui',c.image)));}
 const kg=data.weapons.find(w=>w.name==='KG-7 Vulcan');assert.equal(kg.camos[8].dmz,'Get 25 Enemy Hipfire Kills');assert.equal(kg.camos[9].dmz,'Get 75 Headshot Kills against Enemies');
 assert.ok(data.weapons.every(w=>w.camos[13].unlock==='33 Platinum weapons'));
});
