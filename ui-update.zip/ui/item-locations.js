const ITEM_LOCATIONS={"Biomaterials": "Hospitals; chemical lockers.", "Control Unit": "Computers; tech bags.", "Detonators": "Military or industrial areas.", "Electronic Sensors": "Tech bags; commercial areas.", "Binding Catalyst": "Mirae General Hospital; medical tents.", "CPU": "Netshin Tech Complex; Cheonwang Peak Array servers; Deadtown hills.", "Comms Module": "Netshin and Cheonwang servers; Deadtown; crashed-drone panels.", "Nitro Compounds": "NuriGO DRC lab; Citadel chemical buildings; Imjin tents.", "Nylon Cloth": "Citadel wings; Deadtown underground; Mujin Nightclub.", "Nylon Laminate": "Citadel wings; Deadtown underground; Mujin Nightclub.", "Structural Alloy": "Chang-san hangars/repair bays; Bubun Yard.", "Alloyed Plating": "Chang-san; Bubun Yard; reported Revolution Dam locker.", "Ballistic Fabric": "Chang-san armory/barracks; La Grande Vie rooftop.", "Stock Rod": "Imjin rice mill; Hajin construction; Namjjog Station.", "Printed Circuit Board": "Reactor/substations; reported airbase bunker shelf.", "Military Composites": "Reported Colossus loot.", "Nano-Structured Alloy": "Reported Tank loot.", "Experimental Compounds": "Occasional Commander loot; reported Imjin roadside find.", "Regional Combat Notes": "Care packages; Bravo safe; border cash register; Special Delivery; Signal Breaker.", "Infantry Invasion Plans": "Charlie/Delta safes; Signal Breaker; airbase chemical storage; care packages.", "Power Regulator": "Cheonwang server blades; Reactor 02 Chemical Storage.", "Reactive Metals": "Industrial areas; toolboxes.", "Synthetics": "General resource looting: homes and gas stations.", "Electronics": "General resource looting: homes and gas stations.", "Chemicals": "General resource looting: homes and gas stations.", "Metals": "General resource looting: homes and gas stations."};
// Broad search-area anchors for named places already listed in the material guide.
// These are area hints, never exact or guaranteed item spawns.
const ITEM_MAP_AREAS={
 'Binding Catalyst':['Mirae General Hospital'],
 'CPU':['Cheonwang Peak Array','Deadtown'],
 'Comms Module':['Cheonwang Peak Array','Deadtown'],
 'Nitro Compounds':['The Citadel'],
 'Nylon Cloth':['The Citadel','Deadtown'],
 'Nylon Laminate':['The Citadel','Deadtown'],
 'Structural Alloy':['Chang-san Air Base'],
 'Alloyed Plating':['Chang-san Air Base','Revolution Dam'],
 'Ballistic Fabric':['Chang-san Air Base'],
 'Stock Rod':['Imjin Farmland','Construction Zone'],
 'Printed Circuit Board':['Haneul Nuclear Reactor','Chang-san Air Base'],
 'Infantry Invasion Plans':['Chang-san Air Base'],
 'Power Regulator':['Cheonwang Peak Array','Haneul Nuclear Reactor']
};
