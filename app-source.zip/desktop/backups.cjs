const fs = require('node:fs/promises');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
function validateBackup(data) {
  if (!data || data.format !== 'mw4-mastery-v1' || !data.checks || Array.isArray(data.checks) || typeof data.checks !== 'object' || Object.values(data.checks).some(v => typeof v !== 'boolean')) throw new Error('Choose a valid MW4 progress backup.');
  return data;
}
async function writeBackup(directory, data, metadata = {}) {
  validateBackup(data);
  await fs.mkdir(directory, { recursive: true });
  const stamp = new Date().toISOString();
  const file = path.join(directory, `MW4-progress-${stamp.replace(/[:.]/g, '-')}-${randomUUID().slice(0,8)}.json`);
  const payload = JSON.stringify({ ...data, exportedAt: stamp, backupInfo: metadata }, null, 2);
  await fs.writeFile(file, payload, { flag: 'wx' });
  if (await fs.readFile(file, 'utf8') !== payload) throw new Error('The progress backup could not be verified.');
  return file;
}
async function readBackup(file) {
  if ((await fs.stat(file)).size > 20 * 1024 * 1024) throw new Error('Choose a progress backup smaller than 20 MB.');
  return validateBackup(JSON.parse((await fs.readFile(file, 'utf8')).replace(/^\uFEFF/, '')));
}
module.exports = { validateBackup, writeBackup, readBackup };
