const test = require('node:test'), assert = require('node:assert/strict'), path = require('node:path'), fs = require('node:fs');
const { resolveAsset, isLocalPage, isExternalLink } = require('../desktop/security.cjs');
test('local protocol rejects traversal and untrusted origins', () => {
 const root=path.resolve(__dirname,'../ui');
 assert.equal(resolveAsset(root,'app://tracker/index.html'),path.join(root,'index.html'));
 assert.equal(resolveAsset(root,'https://evil.example/index.html'),null);
 assert.equal(resolveAsset(root,'app://evil/index.html'),null);
 assert.equal(resolveAsset(root,'app://tracker/%2e%2e%2fpackage.json'),null);
 assert.equal(resolveAsset(root,'app://tracker/%5csecret'),null);
 assert.equal(isLocalPage('app://tracker/index.html'),true);
 assert.equal(isExternalLink('javascript:alert(1)'),false);
});
test('public package starts with blank progress and embedded local data',()=>{
 const data=fs.readFileSync(path.resolve(__dirname,'../ui/data.js'),'utf8');
 const parsed=JSON.parse(data.slice(data.indexOf('=')+1).trim().replace(/;$/,''));
 assert(Object.values(parsed.initial).every(x=>x===false));
 const html=fs.readFileSync(path.resolve(__dirname,'../ui/index.html'),'utf8');
 assert(!/<script[^>]+src="https?:/.test(html));
 assert(html.includes('desktop-status.js'));
});
